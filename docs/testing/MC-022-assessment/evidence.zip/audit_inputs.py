"""Independent MC-022 provenance/dependency/reference checks. No HEAD inference."""
import hashlib, json, pathlib, subprocess, tomllib, tarfile
BASE = pathlib.Path(__file__).resolve().parent
REPO = BASE.parents[2]
SOURCE = BASE / 'source'
CANDIDATE = 'ad87cf890459cd43e1e10991085440ebd6d48cb9'
PRODUCTION = '835a7966f4edb2dead99f5768ec24b75059a337c'
def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])
files = []
for record in git('ls-tree', '-rz', CANDIDATE).split(b'\0'):
    if not record: continue
    meta, name = record.split(b'\t', 1)
    mode, kind, blob = meta.split()
    assert kind == b'blob', record
    path = name.decode()
    raw = (SOURCE/path).read_bytes()
    actual = hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()
    transformed = False
    if actual != blob.decode():
        normalized = raw.replace(b'\r\n', b'\n')
        actual = hashlib.sha1(b'blob ' + str(len(normalized)).encode() + b'\0' + normalized).hexdigest()
        assert actual == blob.decode(), path
        transformed = True
    files.append({'path': path, 'git_blob':actual, 'snapshot_crlf_transform':transformed, 'sha256':hashlib.sha256(raw).hexdigest()})
assert not git('diff', '--name-only', PRODUCTION, CANDIDATE, '--', 'src', 'Cargo.toml', 'Cargo.lock')
lock = tomllib.loads((SOURCE/'Cargo.lock').read_text())['package']
packages = lambda p: {(x['name'], x['version'], x.get('source'), x.get('checksum')) for x in tomllib.loads(p.read_text())['package']}
assert packages(SOURCE/'tests/integration/Cargo.lock') - packages(SOURCE/'Cargo.lock') == {('meshchat-wire-checks','0.1.0',None,None)}
registry = REPO/'.work/cargo/registry'
checked, missing = [], []
for package in lock:
    if 'checksum' not in package: continue
    archive = next((registry/'cache').glob(f"*/{package['name']}-{package['version']}.crate"), None)
    if archive is None:
        missing.append([package['name'], package['version']]); continue
    assert hashlib.sha256(archive.read_bytes()).hexdigest() == package['checksum'], str(archive)
    checked.append([package['name'],package['version'],package['checksum']])
critical = ['hpke-0.14.1','ed25519-dalek-2.2.0','x25519-dalek-2.0.1','x25519-dalek-3.0.0','curve25519-dalek-4.1.3','curve25519-dalek-5.0.0','chacha20poly1305-0.11.0','poly1305-0.9.1','hmac-0.13.0','hkdf-0.13.0','sha2-0.11.0','sha2-0.10.9','zeroize-1.8.1','getrandom-0.4.3']
critical_sources = {}
for name in critical:
    root = next((registry/'src').glob('*/'+name))
    archive = next((registry/'cache').glob('*/'+name+'.crate'))
    count = 0
    with tarfile.open(archive) as tar:
        for member in tar.getmembers():
            if not member.isfile(): continue
            path = pathlib.PurePosixPath(member.name).relative_to(name)
            assert (root/path).read_bytes() == tar.extractfile(member).read(), f'{name}/{path}'
            count += 1
    critical_sources[name] = count
for family in ['friend','dm','organizer']:
    raw = subprocess.check_output(['C:/Program Files/nodejs/node.exe',str(SOURCE/f'tests/vectors/crypto/{family}_vectors.cjs')], cwd=SOURCE)
    assert raw.decode().splitlines() == (SOURCE/f'tests/vectors/crypto/{family}-v1.tsv').read_text().splitlines()
report = {'candidate':CANDIDATE,'production':PRODUCTION,'tracked_files':files,'production_unchanged':True,'verified_crate_archives':checked,'uncached_crate_archives':missing,'verified_critical_source_file_counts':critical_sources,'reference_families':['friend','dm','organizer'],'node_openssl':subprocess.check_output(['C:/Program Files/nodejs/node.exe','-p','process.version + " / OpenSSL " + process.versions.openssl']).decode().strip()}
(BASE/'provenance-results.json').write_text(json.dumps(report,indent=2)+'\n')
print(f'{len(files)} tracked snapshot files match exact candidate after documented CRLF normalization; production unchanged.')
print(f'{sum(f["snapshot_crlf_transform"] for f in files)} snapshot files needed CRLF normalization to match Git blob.')
print(f'{len(checked)} crate archive checksums verified; {len(missing)} archives not cached.')
print(f'{len(critical_sources)} critical extracted crate trees verified against package checksums.')
print('All three reference families reproduce; facade dependency addition is test package only.')
