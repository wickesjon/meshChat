"""Explicit-revision provenance for the independent MC-022 remediation retest."""
from pathlib import Path
import hashlib, json, subprocess
BASE=Path(__file__).resolve().parent
REPO=BASE.parents[2]
SOURCE=BASE/'retest-source'
OLD='ad87cf890459cd43e1e10991085440ebd6d48cb9'
REV='695fbc44e472e1f6a5664c9ec0cb3b8a0cc8f792'
def git(*args):return subprocess.check_output(['git','-C',str(REPO),*args])
files=[]
for entry in git('ls-tree','-rz',REV).split(b'\0'):
    if not entry:continue
    meta,name=entry.split(b'\t',1); mode,kind,blob=meta.split()
    assert kind==b'blob'
    raw=(SOURCE/name.decode()).read_bytes()
    def oid(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
    transform=oid(raw)!=blob.decode()
    assert oid(raw.replace(b'\r\n',b'\n') if transform else raw)==blob.decode(),name
    files.append({'path':name.decode(),'git_blob':blob.decode(),'sha256':hashlib.sha256(raw).hexdigest(),'crlf_transform':transform})
changed=git('diff','--name-only',OLD,REV,'--','src','Cargo.lock','Cargo.toml').decode().splitlines()
assert set(changed)=={f'src/core/src/{x}.rs' for x in ['friends','ingress','organizer','storage','text']},changed
for family in ['friend','dm','organizer']:
    actual=subprocess.check_output(['C:/Program Files/nodejs/node.exe',str(SOURCE/f'tests/vectors/crypto/{family}_vectors.cjs')],cwd=SOURCE).decode()
    assert actual.splitlines()==(SOURCE/f'tests/vectors/crypto/{family}-v1.tsv').read_text().splitlines()
result={'revision':REV,'previous_revision':OLD,'changed_production_paths':changed,'tracked_files':files,'references_match':True}
(BASE/'retest-inputs.json').write_text(json.dumps(result,indent=2)+'\n')
print(f'{len(files)} tracked files match {REV}; {sum(x["crlf_transform"] for x in files)} have documented CRLF transformation.')
print('Only five approved production files changed; manifest/lockfile unchanged; all three reference families match.')
